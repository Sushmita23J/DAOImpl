package com.tap.dao;

import com.tap.models.Student;

public interface StudentDAO {

	int addStudent(Student stu);
}
